﻿import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  standalone: true, imports: [ReactiveFormsModule],
  template: <h2>Login</h2><form [formGroup]="form" (submit)="login()"><input formControlName="username" placeholder="User"/><input formControlName="password" type="password"/><button>Login</button></form>
})
export class LoginComponent {
  form: FormGroup;
  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router) {
    this.form = this.fb.group({ username: [''], password: [''] });
  }
  login() {
    this.http.post<any>('http://localhost:5000/api/auth/login', this.form.value).subscribe(res => {
      localStorage.setItem('token', res.token);
      if(res.role === 'Admin') this.router.navigate(['/admin']);
      else this.router.navigate(['/customer']);
    });
  }
}
