﻿using DotNet_Backend.Data;
using DotNet_Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DotNet_Backend.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class ServiceController : ControllerBase
{
    private readonly AppDbContext _context;

    public ServiceController(AppDbContext context) { _context = context; }

    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> GetServices() => Ok(await _context.Services.ToListAsync());

    [HttpPost]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateService([FromBody] Service service)
    {
        _context.Services.Add(service);
        await _context.SaveChangesAsync();
        return Ok(service);
    }
}
