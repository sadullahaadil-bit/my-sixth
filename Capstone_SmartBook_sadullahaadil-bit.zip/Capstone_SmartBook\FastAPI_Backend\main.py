﻿import os
import re
from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import google.generativeai as genai
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
from jose import jwt, JWTError

load_dotenv()

app = FastAPI(title="SmartBook AI API")

app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "supersecretkeythatisverylongandsecure123!@#")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")

genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-1.5-flash')

client = AsyncIOMotorClient(MONGO_URI)
db = client.smartbook
history_collection = db.chat_history
summaries_collection = db.appointment_summaries

def get_current_user(request: Request):
    auth = request.headers.get("Authorization")
    if not auth or not auth.startswith("Bearer "): raise HTTPException(status_code=401)
    token = auth.split(" ")[1]
    try: return jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
    except JWTError: raise HTTPException(status_code=401)

def is_admin(user: dict = Depends(get_current_user)):
    if user.get("role") != "Admin": raise HTTPException(status_code=403)
    return user

class ChatReq(BaseModel): session_id: str; prompt: str
class SummaryReq(BaseModel): booking_id: str; service_name: str; time: str
class AdminQueryReq(BaseModel): query: str; data_context: str

def check_injection(prompt: str) -> bool:
    for pat in [r"ignore previous instructions", r"pretend you are"]:
        if re.search(pat, prompt, re.IGNORECASE): return True
    return False

@app.post("/chat")
async def chat(req: ChatReq, user: dict = Depends(get_current_user)):
    if check_injection(req.prompt): raise HTTPException(status_code=400, detail="Injection detected")
    await history_collection.insert_one({"session_id": req.session_id, "user_id": user.get("sub"), "role": "user", "content": req.prompt})
    cursor = history_collection.find({"session_id": req.session_id}).sort("_id", 1)
    docs = await cursor.to_list(length=20)
    messages = [{"role": "user" if d["role"] == "user" else "model", "parts": [d["content"]]} for d in docs[:-1]]
    messages.append({"role": "user", "parts": [req.prompt]})

    try:
        response = model.generate_content(messages, stream=True)
        async def stream_gen():
            full = ""
            for chunk in response:
                if chunk.text: full += chunk.text; yield chunk.text
            await history_collection.insert_one({"session_id": req.session_id, "user_id": user.get("sub"), "role": "model", "content": full})
        return StreamingResponse(stream_gen(), media_type="text/plain")
    except Exception as e: raise HTTPException(status_code=500, detail=str(e))

@app.post("/generate-summary")
async def generate_summary(req: SummaryReq):
    prompt = f"Generate a personalized appointment summary for a {req.service_name} scheduled at {req.time}. Include preparation notes."
    response = model.generate_content(prompt)
    await summaries_collection.insert_one({"booking_id": req.booking_id, "summary": response.text})
    return {"status": "created"}

@app.get("/summary/{booking_id}")
async def get_summary(booking_id: str, user: dict = Depends(get_current_user)):
    doc = await summaries_collection.find_one({"booking_id": booking_id})
    return {"summary": doc["summary"] if doc else "No summary available."}

@app.post("/admin-query")
async def admin_query(req: AdminQueryReq, user: dict = Depends(is_admin)):
    prompt = f"Based on this JSON data: {req.data_context}, answer the following query: {req.query}"
    response = model.generate_content(prompt)
    return {"response": response.text}

@app.get("/history")
async def get_history(session_id: str, user: dict = Depends(get_current_user)):
    docs = await history_collection.find({"session_id": session_id}).to_list(length=100)
    for d in docs: d["_id"] = str(d["_id"])
    return docs
