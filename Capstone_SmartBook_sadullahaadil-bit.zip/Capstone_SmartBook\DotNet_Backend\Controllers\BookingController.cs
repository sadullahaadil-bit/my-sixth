﻿using System.Security.Claims;
using DotNet_Backend.Data;
using DotNet_Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Text;

namespace DotNet_Backend.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class BookingController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly IHttpClientFactory _clientFactory;
    private readonly IConfiguration _configuration;

    public BookingController(AppDbContext context, IHttpClientFactory clientFactory, IConfiguration configuration)
    {
        _context = context;
        _clientFactory = clientFactory;
        _configuration = configuration;
    }

    [HttpPost]
    public async Task<IActionResult> Book([FromBody] Appointment appt)
    {
        var role = User.FindFirstValue(ClaimTypes.Role);
        if (role == "Customer") appt.CustomerId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

        var conflict = await _context.Appointments.AnyAsync(a => a.StaffId == appt.StaffId && a.BookingTime == appt.BookingTime && a.Status == "Scheduled");
        if (conflict) return BadRequest("Time slot not available.");

        _context.Appointments.Add(appt);
        await _context.SaveChangesAsync();

        // Trigger FastAPI for Summary
        try {
            var service = await _context.Services.FindAsync(appt.ServiceId);
            var client = _clientFactory.CreateClient();
            var payload = new { booking_id = appt.Id.ToString(), service_name = service?.Name, time = appt.BookingTime.ToString("yyyy-MM-dd HH:mm") };
            var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
            await client.PostAsync(_configuration["FastAPI:BaseUrl"] + "/generate-summary", content);
        } catch { /* Ignore notification failure */ }

        return Ok(appt);
    }

    [HttpGet]
    public async Task<IActionResult> GetAppointments()
    {
        var role = User.FindFirstValue(ClaimTypes.Role);
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

        if (role == "Admin") return Ok(await _context.Appointments.ToListAsync());
        if (role == "Staff") return Ok(await _context.Appointments.Where(a => a.StaffId == userId).ToListAsync());
        return Ok(await _context.Appointments.Where(a => a.CustomerId == userId).ToListAsync());
    }
}
