﻿using DotNet_Backend.Models;
using Microsoft.EntityFrameworkCore;

namespace DotNet_Backend.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users { get; set; }
    public DbSet<Service> Services { get; set; }
    public DbSet<StaffAssignment> StaffAssignments { get; set; }
    public DbSet<Appointment> Appointments { get; set; }
}
