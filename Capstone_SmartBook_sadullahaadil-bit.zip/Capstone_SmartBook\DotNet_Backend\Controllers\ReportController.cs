﻿using DotNet_Backend.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DotNet_Backend.Controllers;

[Authorize(Roles = "Admin")]
[ApiController]
[Route("api/[controller]")]
public class ReportController : ControllerBase
{
    private readonly AppDbContext _context;

    public ReportController(AppDbContext context) { _context = context; }

    [HttpGet]
    public async Task<IActionResult> GetDashboardStats()
    {
        var thirtyDaysAgo = DateTime.UtcNow.AddDays(-30);
        var recentAppts = await _context.Appointments.Where(a => a.BookingTime >= thirtyDaysAgo).ToListAsync();
        
        var totalRevenue = recentAppts.Where(a => a.Status == "Completed").Sum(a => a.Amount);
        var topServices = recentAppts.GroupBy(a => a.ServiceId).OrderByDescending(g => g.Count()).Take(3).Select(g => new { ServiceId = g.Key, Count = g.Count() });

        return Ok(new { TotalRevenue = totalRevenue, Bookings = recentAppts.Count, TopServices = topServices });
    }
}
