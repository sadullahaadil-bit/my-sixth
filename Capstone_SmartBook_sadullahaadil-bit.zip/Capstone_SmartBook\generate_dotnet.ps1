$dotnetDir = "C:\Users\sadul\.gemini\antigravity\scratch\Capstone_SmartBook\DotNet_Backend"

New-Item -ItemType Directory -Force -Path $dotnetDir\Data | Out-Null
New-Item -ItemType Directory -Force -Path $dotnetDir\Models | Out-Null
New-Item -ItemType Directory -Force -Path $dotnetDir\Controllers | Out-Null

$csproj = @"
<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="8.0.0" />
    <PackageReference Include="Microsoft.EntityFrameworkCore.Design" Version="8.0.0">
      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
      <PrivateAssets>all</PrivateAssets>
    </PackageReference>
    <PackageReference Include="Pomelo.EntityFrameworkCore.MySql" Version="8.0.0" />
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
</Project>
"@
Set-Content -Path "$dotnetDir\DotNet_Backend.csproj" -Value $csproj -Encoding UTF8

$appsettings = @"
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*",
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=SmartBookDb;User=root;Password=;"
  },
  "Jwt": {
    "Key": "supersecretkeythatisverylongandsecure123!@#",
    "Issuer": "SmartBookApp",
    "Audience": "SmartBookUsers"
  },
  "FastAPI": {
    "BaseUrl": "http://localhost:8000"
  }
}
"@
Set-Content -Path "$dotnetDir\appsettings.json" -Value $appsettings -Encoding UTF8

$program = @"
using System.Text;
using DotNet_Backend.Data;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString)));

builder.Services.AddControllers();
builder.Services.AddHttpClient();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        builder => builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
});

var jwtKey = builder.Configuration["Jwt:Key"];
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey))
        };
    });

var app = builder.Build();
app.UseCors("AllowAll");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();
"@
Set-Content -Path "$dotnetDir\Program.cs" -Value $program -Encoding UTF8

$dbcontext = @"
using DotNet_Backend.Models;
using Microsoft.EntityFrameworkCore;

namespace DotNet_Backend.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users { get; set; }
    public DbSet<Service> Services { get; set; }
    public DbSet<StaffAssignment> StaffAssignments { get; set; }
    public DbSet<Appointment> Appointments { get; set; }
}
"@
Set-Content -Path "$dotnetDir\Data\AppDbContext.cs" -Value $dbcontext -Encoding UTF8

$models = @"
using System.ComponentModel.DataAnnotations;

namespace DotNet_Backend.Models;

public class User
{
    [Key] public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty; // Admin, Staff, Customer
    public bool IsActive { get; set; } = true;
}

public class Service
{
    [Key] public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public int DurationMinutes { get; set; }
    public decimal Price { get; set; }
}

public class StaffAssignment
{
    [Key] public int Id { get; set; }
    public int UserId { get; set; }
    public int ServiceId { get; set; }
    public string WorkingHours { get; set; } = string.Empty; // e.g. "Mon-Fri 9-5"
}

public class Appointment
{
    [Key] public int Id { get; set; }
    public int CustomerId { get; set; }
    public int StaffId { get; set; }
    public int ServiceId { get; set; }
    public DateTime BookingTime { get; set; }
    public string Status { get; set; } = "Scheduled"; // Scheduled, Completed, No-Show, Cancelled
    public decimal Amount { get; set; }
}
"@
Set-Content -Path "$dotnetDir\Models\AllModels.cs" -Value $models -Encoding UTF8

$authcontroller = @"
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using DotNet_Backend.Data;
using DotNet_Backend.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace DotNet_Backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly IConfiguration _configuration;

    public AuthController(AppDbContext context, IConfiguration configuration)
    {
        _context = context;
        _configuration = configuration;
    }

    public class AuthRequest { public string Username { get; set; } public string Password { get; set; } public string Role { get; set; } }

    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] AuthRequest request)
    {
        if (await _context.Users.AnyAsync(u => u.Username == request.Username)) return BadRequest("User exists");
        var user = new User { Username = request.Username, PasswordHash = request.Password, Role = request.Role ?? "Customer" };
        _context.Users.Add(user);
        await _context.SaveChangesAsync();
        return Ok("User registered");
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] AuthRequest request)
    {
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == request.Username && u.PasswordHash == request.Password && u.IsActive);
        if (user == null) return Unauthorized();

        var tokenHandler = new JwtSecurityTokenHandler();
        var key = Encoding.ASCII.GetBytes(_configuration["Jwt:Key"]);
        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(new[] { 
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim("sub", user.Id.ToString()),
                new Claim(ClaimTypes.Role, user.Role),
                new Claim(ClaimTypes.Name, user.Username) 
            }),
            Expires = DateTime.UtcNow.AddDays(7),
            Issuer = _configuration["Jwt:Issuer"],
            Audience = _configuration["Jwt:Audience"],
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
        };
        var token = tokenHandler.CreateToken(tokenDescriptor);
        return Ok(new { token = tokenHandler.WriteToken(token), role = user.Role });
    }
}
"@
Set-Content -Path "$dotnetDir\Controllers\AuthController.cs" -Value $authcontroller -Encoding UTF8

$servicecontroller = @"
using DotNet_Backend.Data;
using DotNet_Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DotNet_Backend.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class ServiceController : ControllerBase
{
    private readonly AppDbContext _context;

    public ServiceController(AppDbContext context) { _context = context; }

    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> GetServices() => Ok(await _context.Services.ToListAsync());

    [HttpPost]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateService([FromBody] Service service)
    {
        _context.Services.Add(service);
        await _context.SaveChangesAsync();
        return Ok(service);
    }
}
"@
Set-Content -Path "$dotnetDir\Controllers\ServiceController.cs" -Value $servicecontroller -Encoding UTF8

$bookingcontroller = @"
using System.Security.Claims;
using DotNet_Backend.Data;
using DotNet_Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Text;

namespace DotNet_Backend.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class BookingController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly IHttpClientFactory _clientFactory;
    private readonly IConfiguration _configuration;

    public BookingController(AppDbContext context, IHttpClientFactory clientFactory, IConfiguration configuration)
    {
        _context = context;
        _clientFactory = clientFactory;
        _configuration = configuration;
    }

    [HttpPost]
    public async Task<IActionResult> Book([FromBody] Appointment appt)
    {
        var role = User.FindFirstValue(ClaimTypes.Role);
        if (role == "Customer") appt.CustomerId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

        var conflict = await _context.Appointments.AnyAsync(a => a.StaffId == appt.StaffId && a.BookingTime == appt.BookingTime && a.Status == "Scheduled");
        if (conflict) return BadRequest("Time slot not available.");

        _context.Appointments.Add(appt);
        await _context.SaveChangesAsync();

        // Trigger FastAPI for Summary
        try {
            var service = await _context.Services.FindAsync(appt.ServiceId);
            var client = _clientFactory.CreateClient();
            var payload = new { booking_id = appt.Id.ToString(), service_name = service?.Name, time = appt.BookingTime.ToString("yyyy-MM-dd HH:mm") };
            var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
            await client.PostAsync(_configuration["FastAPI:BaseUrl"] + "/generate-summary", content);
        } catch { /* Ignore notification failure */ }

        return Ok(appt);
    }

    [HttpGet]
    public async Task<IActionResult> GetAppointments()
    {
        var role = User.FindFirstValue(ClaimTypes.Role);
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

        if (role == "Admin") return Ok(await _context.Appointments.ToListAsync());
        if (role == "Staff") return Ok(await _context.Appointments.Where(a => a.StaffId == userId).ToListAsync());
        return Ok(await _context.Appointments.Where(a => a.CustomerId == userId).ToListAsync());
    }
}
"@
Set-Content -Path "$dotnetDir\Controllers\BookingController.cs" -Value $bookingcontroller -Encoding UTF8

$reportcontroller = @"
using DotNet_Backend.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DotNet_Backend.Controllers;

[Authorize(Roles = "Admin")]
[ApiController]
[Route("api/[controller]")]
public class ReportController : ControllerBase
{
    private readonly AppDbContext _context;

    public ReportController(AppDbContext context) { _context = context; }

    [HttpGet]
    public async Task<IActionResult> GetDashboardStats()
    {
        var thirtyDaysAgo = DateTime.UtcNow.AddDays(-30);
        var recentAppts = await _context.Appointments.Where(a => a.BookingTime >= thirtyDaysAgo).ToListAsync();
        
        var totalRevenue = recentAppts.Where(a => a.Status == "Completed").Sum(a => a.Amount);
        var topServices = recentAppts.GroupBy(a => a.ServiceId).OrderByDescending(g => g.Count()).Take(3).Select(g => new { ServiceId = g.Key, Count = g.Count() });

        return Ok(new { TotalRevenue = totalRevenue, Bookings = recentAppts.Count, TopServices = topServices });
    }
}
"@
Set-Content -Path "$dotnetDir\Controllers\ReportController.cs" -Value $reportcontroller -Encoding UTF8
