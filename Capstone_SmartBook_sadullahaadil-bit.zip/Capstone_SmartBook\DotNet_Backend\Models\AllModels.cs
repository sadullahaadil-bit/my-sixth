﻿using System.ComponentModel.DataAnnotations;

namespace DotNet_Backend.Models;

public class User
{
    [Key] public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty; // Admin, Staff, Customer
    public bool IsActive { get; set; } = true;
}

public class Service
{
    [Key] public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public int DurationMinutes { get; set; }
    public decimal Price { get; set; }
}

public class StaffAssignment
{
    [Key] public int Id { get; set; }
    public int UserId { get; set; }
    public int ServiceId { get; set; }
    public string WorkingHours { get; set; } = string.Empty; // e.g. "Mon-Fri 9-5"
}

public class Appointment
{
    [Key] public int Id { get; set; }
    public int CustomerId { get; set; }
    public int StaffId { get; set; }
    public int ServiceId { get; set; }
    public DateTime BookingTime { get; set; }
    public string Status { get; set; } = "Scheduled"; // Scheduled, Completed, No-Show, Cancelled
    public decimal Amount { get; set; }
}
