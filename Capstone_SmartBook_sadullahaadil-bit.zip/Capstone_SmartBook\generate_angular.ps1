$ngDir = "C:\Users\sadul\.gemini\antigravity\scratch\Capstone_SmartBook\Angular_Frontend"

New-Item -ItemType Directory -Force -Path $ngDir\src\app\components\auth | Out-Null
New-Item -ItemType Directory -Force -Path $ngDir\src\app\components\admin | Out-Null
New-Item -ItemType Directory -Force -Path $ngDir\src\app\components\customer | Out-Null
New-Item -ItemType Directory -Force -Path $ngDir\src\app\services | Out-Null
New-Item -ItemType Directory -Force -Path $ngDir\src\app\guards | Out-Null

$pkg = @"
{
  "name": "smartbook-frontend",
  "version": "0.0.0",
  "scripts": { "ng": "ng", "start": "ng serve", "build": "ng build" },
  "dependencies": {
    "@angular/common": "^17.0.0", "@angular/core": "^17.0.0", "@angular/forms": "^17.0.0",
    "@angular/platform-browser": "^17.0.0", "@angular/platform-browser-dynamic": "^17.0.0", "@angular/router": "^17.0.0",
    "rxjs": "~7.8.0", "zone.js": "~0.14.2", "chart.js": "^4.4.0"
  },
  "devDependencies": { "@angular-devkit/build-angular": "^17.0.0", "@angular/cli": "^17.0.0", "typescript": "~5.2.2" }
}
"@
Set-Content -Path "$ngDir\package.json" -Value $pkg -Encoding UTF8

$angularjson = @"
{
  "`$schema": "./node_modules/@angular/cli/lib/config/schema.json", "version": 1, "newProjectRoot": "projects",
  "projects": { "smartbook-frontend": { "projectType": "application", "root": "", "sourceRoot": "src", "prefix": "app", "architect": { "build": { "builder": "@angular-devkit/build-angular:browser", "options": { "outputPath": "dist/smartbook", "index": "src/index.html", "main": "src/main.ts", "polyfills": ["zone.js"], "tsConfig": "tsconfig.app.json" } }, "serve": { "builder": "@angular-devkit/build-angular:dev-server", "options": { "buildTarget": "smartbook-frontend:build" } } } } }
}
"@
Set-Content -Path "$ngDir\angular.json" -Value $angularjson -Encoding UTF8

$tsconfig = @"
{ "compilerOptions": { "baseUrl": "./", "outDir": "./dist/out-tsc", "strict": true, "target": "ES2022", "module": "ES2022", "lib": ["ES2022", "dom"] } }
"@
Set-Content -Path "$ngDir\tsconfig.json" -Value $tsconfig -Encoding UTF8

$tsconfigapp = @"
{ "extends": "./tsconfig.json", "compilerOptions": { "outDir": "./out-tsc/app" }, "files": ["src/main.ts"] }
"@
Set-Content -Path "$ngDir\tsconfig.app.json" -Value $tsconfigapp -Encoding UTF8

$index = @"
<!doctype html><html lang="en"><head><title>SmartBook</title><base href="/"></head><body><app-root></app-root></body></html>
"@
Set-Content -Path "$ngDir\src\index.html" -Value $index -Encoding UTF8

$maints = @"
import { bootstrapApplication } from '@angular/platform-browser';
import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { AppComponent } from './app/app.component';
import { routes } from './app/app.routes';
import { authInterceptor } from './app/services/auth.interceptor';

export const appConfig: ApplicationConfig = { providers: [provideRouter(routes), provideHttpClient(withInterceptors([authInterceptor]))] };
bootstrapApplication(AppComponent, appConfig).catch(err => console.error(err));
"@
Set-Content -Path "$ngDir\src\main.ts" -Value $maints -Encoding UTF8

$appcomponent = @"
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
@Component({ selector: 'app-root', standalone: true, imports: [RouterOutlet], template: '<router-outlet></router-outlet>' })
export class AppComponent {}
"@
Set-Content -Path "$ngDir\src\app\app.component.ts" -Value $appcomponent -Encoding UTF8

$authinterceptor = @"
import { HttpInterceptorFn } from '@angular/common/http';
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = localStorage.getItem('token');
  if (token) return next(req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }));
  return next(req);
};
"@
Set-Content -Path "$ngDir\src\app\services\auth.interceptor.ts" -Value $authinterceptor -Encoding UTF8

$routes = @"
import { Routes } from '@angular/router';
import { LoginComponent } from './components/auth/login.component';
import { AdminComponent } from './components/admin/admin.component';
import { CustomerComponent } from './components/customer/customer.component';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'customer', component: CustomerComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' }
];
"@
Set-Content -Path "$ngDir\src\app\app.routes.ts" -Value $routes -Encoding UTF8

$logincomp = @"
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  standalone: true, imports: [ReactiveFormsModule],
  template: `<h2>Login</h2><form [formGroup]="form" (submit)="login()"><input formControlName="username" placeholder="User"/><input formControlName="password" type="password"/><button>Login</button></form>`
})
export class LoginComponent {
  form: FormGroup;
  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router) {
    this.form = this.fb.group({ username: [''], password: [''] });
  }
  login() {
    this.http.post<any>('http://localhost:5000/api/auth/login', this.form.value).subscribe(res => {
      localStorage.setItem('token', res.token);
      if(res.role === 'Admin') this.router.navigate(['/admin']);
      else this.router.navigate(['/customer']);
    });
  }
}
"@
Set-Content -Path "$ngDir\src\app\components\auth\login.component.ts" -Value $logincomp -Encoding UTF8

$admincomp = @"
import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true, imports: [CommonModule],
  template: `<h2>Admin Dashboard</h2><button (click)="loadStats()">Load Stats</button><pre>{{ stats | json }}</pre>`
})
export class AdminComponent {
  stats: any;
  constructor(private http: HttpClient) {}
  loadStats() { this.http.get('http://localhost:5000/api/report').subscribe(data => this.stats = data); }
}
"@
Set-Content -Path "$ngDir\src\app\components\admin\admin.component.ts" -Value $admincomp -Encoding UTF8

$customercomp = @"
import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true, imports: [ReactiveFormsModule, CommonModule],
  template: `
    <h2>Customer Dashboard</h2>
    <div style="border:1px solid black; padding:10px;">
      <h3>AI Chat</h3>
      <div *ngFor="let m of messages">{{m.role}}: {{m.content}}</div>
      <form [formGroup]="chatForm" (submit)="send()"><input formControlName="prompt"/><button>Send</button></form>
    </div>
  `
})
export class CustomerComponent {
  chatForm: FormGroup; messages: any[] = [];
  constructor(private fb: FormBuilder, private http: HttpClient) { this.chatForm = this.fb.group({ prompt: [''] }); }
  async send() {
    const prompt = this.chatForm.value.prompt;
    this.messages.push({role: 'user', content: prompt});
    this.chatForm.reset();
    const aiIdx = this.messages.push({role: 'ai', content: ''}) - 1;
    
    const res = await fetch('http://localhost:8000/chat', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token')},
      body: JSON.stringify({session_id: '123', prompt})
    });
    const reader = res.body?.getReader();
    const decoder = new TextDecoder();
    while(reader) {
      const {done, value} = await reader.read();
      if(done) break;
      this.messages[aiIdx].content += decoder.decode(value, {stream: true});
    }
  }
}
"@
Set-Content -Path "$ngDir\src\app\components\customer\customer.component.ts" -Value $customercomp -Encoding UTF8

