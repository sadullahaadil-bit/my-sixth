﻿import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true, imports: [CommonModule],
  template: <h2>Admin Dashboard</h2><button (click)="loadStats()">Load Stats</button><pre>{{ stats | json }}</pre>
})
export class AdminComponent {
  stats: any;
  constructor(private http: HttpClient) {}
  loadStats() { this.http.get('http://localhost:5000/api/report').subscribe(data => this.stats = data); }
}
