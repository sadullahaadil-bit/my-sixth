﻿import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true, imports: [ReactiveFormsModule, CommonModule],
  template: 
    <h2>Customer Dashboard</h2>
    <div style="border:1px solid black; padding:10px;">
      <h3>AI Chat</h3>
      <div *ngFor="let m of messages">{{m.role}}: {{m.content}}</div>
      <form [formGroup]="chatForm" (submit)="send()"><input formControlName="prompt"/><button>Send</button></form>
    </div>
  
})
export class CustomerComponent {
  chatForm: FormGroup; messages: any[] = [];
  constructor(private fb: FormBuilder, private http: HttpClient) { this.chatForm = this.fb.group({ prompt: [''] }); }
  async send() {
    const prompt = this.chatForm.value.prompt;
    this.messages.push({role: 'user', content: prompt});
    this.chatForm.reset();
    const aiIdx = this.messages.push({role: 'ai', content: ''}) - 1;
    
    const res = await fetch('http://localhost:8000/chat', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token')},
      body: JSON.stringify({session_id: '123', prompt})
    });
    const reader = res.body?.getReader();
    const decoder = new TextDecoder();
    while(reader) {
      const {done, value} = await reader.read();
      if(done) break;
      this.messages[aiIdx].content += decoder.decode(value, {stream: true});
    }
  }
}
