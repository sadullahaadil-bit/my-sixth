﻿import { Routes } from '@angular/router';
import { LoginComponent } from './components/auth/login.component';
import { AdminComponent } from './components/admin/admin.component';
import { CustomerComponent } from './components/customer/customer.component';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'customer', component: CustomerComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' }
];
